window.LASTWISH_CONFIG = {
  chainId: 1,
  payToAddress: "0x016ae25Ac494B123C40EDb2418d9b1FC2d62279b",
  payAmountEth: 0.0005,
  ensDiscountPercent: 20,
  n8nWebhookUrl: "" // optional webhook
};
